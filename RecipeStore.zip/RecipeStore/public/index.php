<?php









// Require application bootstrap
(require __DIR__ . '/../config/bootstrap.php')->run();